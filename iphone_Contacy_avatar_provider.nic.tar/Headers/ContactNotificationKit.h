#import <ContactNotificationKit/CNContactAvatarProvider.h>

#import <ContactNotificationKit/CNNotification.h>